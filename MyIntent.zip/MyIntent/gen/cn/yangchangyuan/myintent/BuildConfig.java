/** Automatically generated file. DO NOT MODIFY */
package cn.yangchangyuan.myintent;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}