package cn.yangchangyuan.myintent;

import java.io.Serializable;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class RegisterActivity extends Activity {
	private List<User> list;
	private boolean flag = false;
	@SuppressWarnings({ "unchecked", "unused" })
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_register);
		

		list = (List<User>) getIntent().getSerializableExtra("list");
		
		TextView tv_register_name = (TextView) findViewById(R.id.tv_register_name);
		TextView tv_register_password = (TextView) findViewById(R.id.tv_register_password);
		TextView tv_register_checkpassword = (TextView) findViewById(R.id.tv_register_checkpassword);
		
		final EditText et_register_name = (EditText) findViewById(R.id.et_register_name);
		final EditText et_register_password = (EditText) findViewById(R.id.et_register_password);
		final EditText et_register_checkpassword = (EditText) findViewById(R.id.et_register_checkpassword);
		
		Button bt_register_new = (Button) findViewById(R.id.bt_register_new);
		
        bt_register_new.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				String name = et_register_name.getText().toString().trim();
				String password = et_register_password.getText().toString().trim();
				String checkPassword =et_register_checkpassword.getText().toString().trim();
				
				if(name.equals("") || password.equals("") ||checkPassword.equals("")){
					String msg = " �û��������롢ȷ�����벻��Ϊ�գ���";
					Toast.makeText(RegisterActivity.this,msg,Toast.LENGTH_SHORT).show();
				}
				else if(!password.equals(checkPassword)){
						Toast.makeText(RegisterActivity.this,"���롢ȷ���������벻һ�£�",Toast.LENGTH_SHORT).show();
				}
				else if(password.equals(checkPassword)){
					for(User s : list){
						if(name.equals(s.userName)){
							Toast.makeText(RegisterActivity.this," �û����Ѵ��ڣ�",Toast.LENGTH_SHORT).show();
							flag = false;
							break;
						}
						flag = true;
					}
					if(flag){
						list.add(new User(name,password));
						Intent date = new Intent();
						date.putExtra("newList", (Serializable)list);
						date.putExtra("name",name);
						date.putExtra("password", password);
						setResult(RESULT_OK, date);
						finish();
					}
				}
				else{
					Toast.makeText(RegisterActivity.this,"ERROR��",Toast.LENGTH_SHORT).show();
				}
			}
		});
	}	
}
