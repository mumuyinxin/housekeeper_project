package cn.yangchangyuan.myintent;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
	
	protected static final int REGISTER = 0;
	private List<User> list;
	private User user;
	private EditText et_main_name;
	private EditText et_main_password;
	private boolean flag = false;
	
    @SuppressWarnings("unused")
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
    	list = new ArrayList<User>();
    	list.add(new User("stu","123456"));
        TextView tv_main_name = (TextView) findViewById(R.id.tv_main_name);
        et_main_name = (EditText) findViewById(R.id.et_main_name);
        TextView tv_main_password = (TextView) findViewById(R.id.tv_main_password);
        et_main_password = (EditText) findViewById(R.id.et_main_password);
        Button bt_main_login = (Button) findViewById(R.id.bt_main_login);
        TextView tv_main_new = (TextView) findViewById(R.id.tv_main_new);
        
        bt_main_login.setOnClickListener(new OnClickListener() {
		
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				user = new User(et_main_name.getText().toString().trim(),et_main_password.getText().toString().trim());
				if(user.userName.equals("") || user.userPassword.equals("")){
					String msg = " �û��������벻��Ϊ�գ���";
					Toast.makeText(MainActivity.this,msg,Toast.LENGTH_SHORT).show();
				}
				else{
					for(User s: list){
						if(user.equals(s)){
							Intent intent = new Intent(MainActivity.this,WelcomeActivity.class);
							intent.putExtra("name",user.userName + ",��ӭ����");
							flag = true;
							startActivity(intent);
							finish();
						}
					}
					if(!flag){
						String msg = " �û�������������";
						Toast.makeText(MainActivity.this,msg,Toast.LENGTH_SHORT).show();
					}
				}

			}
		});
        tv_main_new.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(MainActivity.this,RegisterActivity.class);
				intent.putExtra("list", (Serializable)list);
				startActivityForResult(intent, REGISTER);
			}
		});
    }
    @SuppressWarnings("unused")
	@Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    	// TODO Auto-generated method stub
    	super.onActivityResult(requestCode, resultCode, data);
    	if(requestCode == REGISTER){
    		if(resultCode==RESULT_OK){
    			
				String name = data.getStringExtra("name");
				list = (List<User>) data.getSerializableExtra("newList");
				String password = data.getStringExtra("password");
				list.add(new User(name,password));
				et_main_name.setText(name);
				
    		}
    	}
    }
}
